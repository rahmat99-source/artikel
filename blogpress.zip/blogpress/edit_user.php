<?php
include 'koneksi.php';

$id = $_GET['id'];

$sql = mysqli_query($koneksi, "SELECT * FROM users WHERE id = '$id'");
$user = mysqli_fetch_array($sql);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Users</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
<h1 align="center">Edit Users</h1>
<div class="main">
    <form action="update_users.php" method="POST">

<input type="hidden" name="id" value="<?php echo $user['id']; ?>">

    <div class="mb-3">
      <label for="namaUser" class="form-label">Nama user</label>
      <input value="<?php echo $user['nama_user']; ?>" type="text" name="nama_user" class="form-control" id="namaUser" 
      placeholder="Masukan nama user" required>
    </div>

    <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Email address</label>
        <input value="<?php echo $user['email']; ?>" type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="nama@gmail.com">
    </div>

    <label for="password" class="form-label">Password</label>
    <input value="<?php echo $user['password']; ?>" type="password" name="password" id="password" class="form-control" aria-describedby="passwordHelpBlock" placeholder="masukan kata sandi">

    <div id="passwordHelpBlock" class="form-text">
        Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
    </div>

    <select name="is_admin" class="form-select" aria-label="Default select example"><?php echo $user['is_admin']; ?>
        <option selected>IS Admin</option>
        <option value="0">0</option>
        <option value="1">1</option>
    </select>
<br>    
      <button type="submit" class="btn btn-primary ">Simpan user</button>
      <a class="btn btn-secondary" href="users.php">Kembali</a></button>
    </form>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>