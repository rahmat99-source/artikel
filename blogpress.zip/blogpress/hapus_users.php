<?php
include 'koneksi.php';

$id = $_GET['id'];

$hapus = mysqli_query($koneksi, "DELETE FROM users WHERE id = '$id'");

header('location: users.php');
?>