<?php
session_start();
include 'koneksi.php';

$nama = $_POST['nama_user'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE (nama_user ='$nama' or email = '$nama') AND password ='$password'";

$user = mysqli_fetch_array(mysqli_query($koneksi, $sql));

if($user){
    
    $_SESSION['nama'] = $user['nama_user'];
    if($user["is_admin"]==1){
        header('Location:artikel.php');
    }else{
        header('Location:home_user.php');
    }
}else{
    header('location:form_login.php');
}

?>