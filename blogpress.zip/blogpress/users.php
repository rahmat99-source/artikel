<?php
include 'koneksi.php';
include 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
        min-height: 2000px;
    }
    h1 {
        padding-top: 100px;
        text-align: center;
    }
    .tambah {
        padding-left: 10px;
        padding-bottom: 20px;
    }
</style>
</head>
<body>
    <h1>Users</h1>
<br><br>
<div class="tambah">
    <a href="tambah_user.php" class="btn btn-primary">Tambah User</a>
</div>
<div>
<table class="table table-hover table-primary text-center">
    <tr>
        <th>Nomor</th>
        <th>Nama User</th>
        <th>Email</th>
        <th>Password</th>
        <th>IS Admin</th>
        <th>Aksi</th>
    </tr>

<?php
$nomor = 1;
$data = mysqli_query($koneksi, "SELECT * FROM users");
while($row = mysqli_fetch_array($data)) {
?>
    <tr>
        <td><?php echo $nomor?></td>
        <td><?php echo $row['nama_user']?></td>
        <td><?php echo $row['email']?></td>
        <td><?php echo $row['password']?></td>
        <td><?php echo $row['is_admin']?></td>
        <td>
            <a href="edit_user.php?id=<?php echo $row['id']?>"
                class="btn btn-primary">Edit</a>

            <a href="hapus_users.php?id=<?php echo $row['id']?>"
                onclick="return confirm('Yakin ingin menghapus data ini?')" class="btn btn-danger">Hapus</a>
        </td>
    </tr>
<?php $nomor++; } ?>
</table>


</div>


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>