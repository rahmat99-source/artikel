<?php
include 'koneksi.php';

$id = $_GET['id'];

$hapus = mysqli_query($koneksi, "DELETE FROM kategori WHERE id = '$id'");

header("location: kategori.php");
?>