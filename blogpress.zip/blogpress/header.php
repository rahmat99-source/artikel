
<link rel="stylesheet" href="css/bootstrap.min.css">
<!-- NAVBAR START -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary position-fixed z-3 w-100" aria-label="Offcanvas navbar large">
    <div class="container-fluid">
      <a class="navbar-brand ps-5 fw-bold fs-4" href="#">BLOGpress.com</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Offcanvas</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body pe-5">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <!-- <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#">About</a>
            </li> -->
            <!-- <li class="nav-item">
              <a class="nav-link" href="#about">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact</a>
            </li> -->

            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Tabel
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Data Artikel</a></li>
                <li><a class="dropdown-item" href="#">Data Users</a></li>
              </ul>
            </li> -->

            <!-- <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Kategori
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Kesehatan dan Kebugaran</a></li>
                <li><a class="dropdown-item" href="#">Teknologi dan Gadget</a></li>
                <li><a class="dropdown-item" href="#">Kuliner dan Resep</a></li>
                <li><a class="dropdown-item" href="#">Traveling dan Destinasi</a></li>
                <li><a class="dropdown-item" href="#">Keuangan Pribadi dan Investasi</a></li>
                <li>
                  <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="#">Something else here</a></li>
              </ul>

            </li> -->
            <li class="nav-item">
              <a class="nav-link" href="artikel.php">Artikel</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="kategori.php">Kategori</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="users.php">Users</a>
            </li>
          </ul>
          
          <div class="logout">
            <a href="logout.php" class="btn btn-outline-danger" onclick="return confirm ('Apakah anda ingin keluar?')">Logout</a>
          </div>
        </div>
      </div>
    </div>
  </nav>
<!-- NAVBAR END -->
<script src="js/bootstrap.bundle.min.js"></script>