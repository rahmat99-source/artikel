<?php
include 'koneksi.php';

$idartikel = $_POST["id"];
$iduser = $_POST["user_id"];
$judul = $_POST["judul"];
$namakategori = $_POST["kategori_id"];
$tanggalpublish = $_POST["tanggal_publish"];
$isiartikel = $_POST["isi_artikel"];
$statusaktif = $_POST["status_aktif"];

// untuk upload cover
$target_dir = "file_cover/";
$nameFile = $_FILES["cover"]["name"];
$target_file = $target_dir . basename($nameFile);
$namasementara = $_FILES['cover']['tmp_name'];
$terupload = move_uploaded_file($namasementara, $target_file);

$sql = mysqli_query($koneksi,"INSERT INTO `artikel`(`id`,`judul`,`tanggal_publish`,`kategori_id`,`isi_artikel`,`cover`,`user_id`,`status_aktif`) VALUES('$idartikel','$judul','$tanggalpublish', '$namakategori', '$isiartikel', '$nameFile', '$iduser', '$statusaktif')");
    
// $simpan = mysqli_query($koneksi, $sql);
header('location:artikel.php');
?>