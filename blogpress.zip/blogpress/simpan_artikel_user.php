<?php
include 'koneksi_user.php';

$idartikel = $_POST["id"];
$iduser = $_POST["user_id"];
$judul = $_POST["judul"];
$namakategori = $_POST["kategori_id"];
$tanggalpublish = $_POST["tanggal_publish"];
$isiartikel = $_POST["isi_artikel"];
$statusaktif = $_POST["status_aktif"];

// untuk upload cover
$target_dir = "file_cover/";
$nameFile = $_FILES["cover"]["name"];
$target_file = $target_dir . basename($nameFile);
$namasementara = $_FILES['cover']['tmp_name'];
$terupload = move_uploaded_file($namasementara, $target_file);

$sql = mysqli_query($koneksi_user,"INSERT INTO artikel VALUES('','$judul','$tanggalpublish', '$namakategori', '$isiartikel', '$nameFile')");
    
// $simpan = mysqli_query($koneksi, $sql);
header('location:artikel_user.php');
?>