<?php
include 'koneksi.php';

$id = $_POST['id'];
$nama_user = $_POST['nama_user'];
$email = $_POST['email'];
$password = $_POST['password'];
$is_admin = $_POST['is_admin'];

$update = mysqli_query($koneksi, "UPDATE users SET 
        nama_user = '$nama_user', 
        email = '$email', 
        password = '$password', 
        is_admin = '$is_admin' 
        WHERE 
        id = '$id' 
        ");


header("location: users.php");
?>