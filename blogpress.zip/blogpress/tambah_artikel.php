<?php
include 'koneksi.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Tambah Artikel</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
        margin: 60px 10px;
        min-height: 2000px;
    }
    h1 {
        text-align: center;
    }
    .container {
      display: flex;
      float: left;
      padding: 20px 0;
      height: 100%;;
      width: 100%;
      
    }
</style>
</head>
<body>
    <h1>Form Tambah Artikel</h1>
<br><br>
<form action="simpan_artikel.php" enctype="multipart/form-data" method="POST">

    <!-- <input type="hidden" name="id_artikel" value=""> -->
    <input type="hidden" name="user_id" value="1">


<div class="mb-3">
  <!-- <label for="id" class="form-label"><b>ID Artikel</b></label> -->
  <input type="hidden" name="id" class="form-control" id="id" placeholder="">
</div>

<div class="mb-3">
  <label for="judul" class="form-label"><b>Judul</b></label>
  <input type="text" name="judul" class="form-control" id="judul" placeholder="masukan judul">
</div>

<label for="kategori" class="form-label"><b>Kategori</b></label>
<select name="kategori_id" class="form-select" aria-label="Default select example">
<!-- memasukan data ke dropdown kategori -->
<?php
  $kategori = mysqli_query($koneksi, "SELECT * FROM kategori");
  while ($k = mysqli_fetch_assoc($kategori)) {
    echo '<option value="'.$k['id'].'">'.$k['nama_kategori'].'</option>';
  }
?>
</select>

<div class="mb-3">
  <label for="tanggalPublish" class="form-label"><b>Tanggal Publish</b></label>
  <input type="date" name="tanggal_publish" class="form-control" id="tanggalPublish" placeholder="">
</div>

<div class="mb-3">
  <label for="isiArtikel" class="form-label"><b>Isi Artikel</b></label>
  <textarea class="form-control" name="isi_artikel" id="isiArtikel" rows="10" placeholder="isi artikel.."></textarea>
</div>

<div class="input-group mb-3">
  <input type="file" name="cover" class="form-control" id="formFileMultiple" multiple>
  <label class="input-group-text" for="cover"><b>Cover</b></label>
</div>

<label for="statusaktif" class="form-label"><b>Status Aktiv</b></label>
<select name="status_aktif" class="form-select" aria-label="Default select example">
  <option selected>Status Aktiv</option>
  <option value="1">Aktiv</option>
  <option value="0">Non Aktiv</option>
</select>

<div class="container">
    <button type="submit"  class="btn btn-primary">Simpan Artikel</button>
    <a href="artikel.php" class="btn btn-secondary">Kembali</a>
</div>
</form>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>