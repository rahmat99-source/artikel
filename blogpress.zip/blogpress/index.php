<?php
include 'koneksi.php';

// Ambil kata kunci pencarian dari URL jika ada
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Mengatur jumlah artikel per halaman
$articlesPerPage = 10;

// Mengambil halaman saat ini dari URL, default ke 1
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$currentPage = max($currentPage, 1); // Pastikan halaman minimal 1

// Hitung offset untuk query
$offset = ($currentPage - 1) * $articlesPerPage;

// Query untuk menghitung total artikel
$countQuery = "SELECT COUNT(*) as total FROM artikel";
if ($searchTerm) {
    $countQuery .= " WHERE judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$countResult = mysqli_query($koneksi, $countQuery);
$totalArticles = mysqli_fetch_assoc($countResult)['total'];

// Hitung total halaman
$totalPages = ceil($totalArticles / $articlesPerPage);

// Query untuk mengambil artikel berdasarkan kata kunci pencarian dan pagination, serta kategori
$query = "SELECT artikel.*, kategori.nama_kategori 
          FROM artikel 
          LEFT JOIN kategori ON artikel.kategori_id = kategori.id";
if ($searchTerm) {
    $query .= " WHERE judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$query .= " LIMIT $offset, $articlesPerPage";

$rows = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
            font-family: sans-serif;
        }
        body {
            background-color: #343a40; /* Warna latar belakang gelap */
        }
        .about, .contact {
            padding: 20px;
            color: white;
        }
        .hero {
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            background-image: url('img/hero.jpeg'); 
            background-size: cover;
        }
        .card {
            transition: transform 0.6s;
            box-sizing: border-box;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .go {
            height: 40px;
            width: 50px;
            border-radius: 5px;
            background-color: white;
            transition: 1s;
        }
        .go:hover {
            rotate: 360deg;
            border-radius: 50px;
            background-color: lightgreen;
        }
        span {
            color: darkred;
        }
        
        /* New styles for the article title hover effect */
        .card-title a {
            color: #333; /* Default color */
            text-decoration: none; /* No underline by default */
        }

        .card-title a:hover {
            color: red; /* Change color on hover */
            text-decoration: underline; /* Underline on hover */
        }
    </style>
</head>
<body>

<!-- NAVBAR START -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary position-fixed z-3 w-100">
    <div class="container-fluid">
        <a class="navbar-brand ps-5 fw-bold fs-4" href="#">BLOGpress.com</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end text-bg-dark" id="offcanvasNavbar2">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">Offcanvas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body pe-5">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 align-items-center">

                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Kategori</a>
                        <ul class="dropdown-menu">

                        <?php
                        // Fetch categories from the database
                        $kategori_query = "SELECT kategori.id, kategori.nama_kategori, COUNT(artikel.id) as jumlah_artikel
                                            FROM kategori LEFT JOIN artikel ON kategori.id = artikel.kategori_id
                                            GROUP BY kategori.id";
                        $kategori_result = $koneksi->query($kategori_query);

                        if ($kategori_result->num_rows > 0) {
                            // Output data for each category
                            while ($kategori = $kategori_result->fetch_assoc()) { ?>
                                <li>
                                    <a href="kategori_detail.php?id=<?php echo $kategori['id'];?>">
                                        <?php echo $kategori['nama_kategori']; ?>
                                        (<?php echo $kategori['jumlah_artikel'];?>)
                                    </a>
                                </li>
                        <?php }
                            } else {
                                echo "<li>No categories found.</li>";
                                } ?>

                        </ul>
                    </li>
                </ul>

                <!-- Searching -->
                <div class="d-flex align-items-center">
                <form class="d-flex mt-3 mt-lg-2 me-lg-5" method="GET" action="">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search.." 
                    value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button class="go" type="submit">Go</button>
                </form>
                </div>
                <!-- End searching -->

                <div class="d-flex align-items-center">
                    <a href="form_login.php" class="btn btn-outline-light">Login</a>
                </div>

            </div>
        </div>
    </div>
</nav>
<!-- NAVBAR END -->

<!-- Hero Section Start -->
<section class="hero">
    <main style="margin-left: 50px; margin-bottom: -300px;">
        <h1 style="font-weight: bolder; font-size: 62px; color: white;">Chosen by Millions,<br>Perfect for You</h1>
        <p style="font-size: 24px; color: white;">Everything you need to build and grow any website—all in one place.</p>
        <br>
        <a href="selengkapnya.php" class="btn btn-primary">Selengkapnya</a>
    </main>
</section>
<!-- Hero Section End -->

<!-- About Section -->
<div class="container mt-5 p-0 text-white" id="about">
    <div class="row">
        <div class="col-md-8">
            <h2>About</h2>
            <hr>
            <p style="text-indent: 45px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo nesciunt, 
                repellat voluptate officia hic obcaecati praesentium natus perferendis recusandae minima dolores autem nostrum minus exercitationem quod! Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                Accusantium in rerum nam quis dolorem sunt consectetur, illo quia. Deleniti quia vel necessitatibus ipsam tempore laborum illum, aperiam aspernatur doloremque similique. 
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Accusamus aperiam natus voluptatum, assumenda ipsum voluptates! Praesentium rem modi excepturi, 
                quaerat beatae nobis repellat nisi porro tenetur perferendis deserunt voluptate repellendus! Doloribus quam alias, possimus reprehenderit ducimus odit distinctio accusantium aliquid sapiente labore, 
                aut corporis nobis obcaecati exercitationem magnam consequuntur impedit id molestiae culpa ad quia nihil tempore. Voluptatibus in quaerat cum velit blanditiis eaque maxime dolor sapiente minima, 
                aliquam at nisi! Sunt cum culpa atque eos minima facilis, sequi quasi aliquam rerum quod nesciunt fugit. Expedita sit iure quidem quis delectus nostrum qui similique non aut! Inventore mollitia quisquam natus.</p>
        </div>
        <div class="col-md-3" style="margin-left: auto;">
            <!-- Sidebar Card -->
            <div class="card bg-secondary text-white">
                <div class="card-header d-flex text-right">
                    Sidebar Title
                </div>
                <div class="card-body" style="padding: 10px;">
                    <img src="img/iklan1.jpg" class="card-img-top" alt="Sidebar Image" style="width: 100%; height: auto; max-height: 150px; object-fit: cover;">
                    <h5 class="card-title" style="font-size: 1.2rem;">Promo Pepsi</h5>
                    <p class="card-text" style="font-size: 0.9rem;">This is some content inside the sidebar. You can put additional information, links, or advertisements here. lorem50</p>
                    <a href="#" class="btn btn-light btn-sm">Buy now!</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contact Section -->
<div class="container mt-5 p-0 text-white" id="contact">
    <div class="row">
        <div class="col-md-8">
            <h2>Contact</h2>
            <hr>
            <p style="text-indent: 45px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo nesciunt, 
                repellat voluptate officia hic obcaecati praesentium natus perferendis recusandae minima dolores autem nostrum minus exercitationem quod! 
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium in rerum nam quis dolorem sunt consectetur, illo quia. Deleniti quia vel necessitatibus ipsam tempore laborum illum, 
                aperiam aspernatur doloremque similique. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum commodi saepe possimus optio necessitatibus inventore quia? 
                Id magni ad assumenda tempore consectetur necessitatibus itaque aliquam sequi voluptates, porro officia expedita dolores est ab fugiat? Eos ipsa repellendus cum? Labore perspiciatis ea fugiat. Omnis, 
                similique ea itaque mollitia iste consectetur dolore!</p>
        </div>
        <div class="col-md-3" style="margin-left: auto;">
            <!-- Sidebar Card -->
            <div class="card bg-secondary text-white">
                <div class="card-header d-flex text-right">
                    Sidebar Title
                </div>
                <div class="card-body" style="padding: 10px;">
                    <img src="img/iklan2.jpg" class="card-img-top" alt="Sidebar Image" style="width: 100%; height: auto; max-height: 150px; object-fit: cover;">
                    <h5 class="card-title" style="font-size: 1.2rem;">Promo Indomie</h5>
                    <p class="card-text" style="font-size: 0.9rem;">This is some content inside the sidebar. You can put additional information, links, or advertisements here.</p>
                    <a href="#" class="btn btn-light btn-sm">Buy now!</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Artikel Section Start -->
<div style="color: #fff; text-align: center; margin-top: 100px; margin-bottom: 50px;">
    <hr><h2>Baca Artikel Populer</h2>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">
        <?php while ($row = mysqli_fetch_assoc($rows)) : ?>
            <div class="col-md-4 mb-4 w-50">
                <div class="card bg-light text-dark">
                    <a href="detail_artikel.php?id=<?php echo $row['id'] ?>">
                        <img src="file_cover/<?php echo $row['cover'] ?>" class="card-img-top" alt="Cover Image">
                        <div class="card-body">
                        <h5 style="font-style: italic;" class="card-title">
                            <a id="title" href="detail_artikel.php?id=<?php echo $row['id'] ?>">
                                <?php echo $row['judul'] ?>
                            </a>
                        </h5>
                        <p><small><span><?= htmlspecialchars($row['nama_kategori']); ?></span> | <?= $row['tanggal_publish']; ?></small></p>
                        <p class="card-text"><?php echo substr($row['isi_artikel'], 0, 100) . '...'; ?></p>
                        </div>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<!-- Artikel Section End -->

<!-- Pagination Start -->
<div>
<nav aria-label="Pagination">
    <ul class="pagination justify-content-center my-4">
        <?php if ($currentPage > 1): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage - 1; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Sebelumnya</a></li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php echo $i == $currentPage ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($currentPage < $totalPages): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage + 1; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Selanjutnya</a></li>
        <?php endif; ?>
    </ul>
</nav>
</div>
<!-- Pagination End -->


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
