<?php

// koneksi ke database
include 'koneksi.php';
// ambil data dari tabel artikel / query data artikel
$result = mysqli_query($koneksi, "SELECT * FROM artikel");
// navbar
include 'header.php';

// if(!isset($_SESSION["login"])){
//     header("location: login.php");
//     exit;
// }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    h1 {
        padding-top: 100px;
        text-align: center;
    }
    .aksi {
        width: 10%;
    }
    .tambah {
        padding-left: 10px;
    }
</style>
</head>
<body>
    <h1>Tabel Artikel</h1>
<br><br>
<div>
<div class="tambah">
    <a href="tambah_artikel.php" class="btn btn-primary ">Tambah Artikel</a></button>
<br><br>
</div>

<table class="table table-hover table-primary">

    <tr align="center">
            <th>No.</th>
            <th>Judul</th>
            <th>Tanggal Publish</th>
            <th>ID Kategori</th>
            <th>Artikel</th> 
            <th>Cover</th> 
            <th>ID User</th>
            <th>Status Aktiv</th>
            <th class="aksi">Aksi</th>
    </tr>

<?php $nomor = 1;?>
   <?php foreach($result as $row) : ?> 
<tr>
    <td><?= $nomor; ?></td>
    <td><?= $row['judul'] ?></td>
    <td><?= $row['tanggal_publish'] ?></td>
    <td align="center"><?= $row['kategori_id'] ?></td>
    <td><?= $row['isi_artikel'] ?></td>
    <td><img src="file_cover/<?= $row['cover'] ?>" width="100px"></td>
    <td align="center"><?= $row['user_id'] ?></td>
    <td align="center"><?= $row['status_aktif'] ?></td>
    <td align="center">
        <a href="edit_artikel.php?id=<?= $row['id'] ?>" 
            class="btn btn-primary btn-sm">Edit</a>
        <a href="hapus_artikel.php?id=<?= $row['id'] ?>" 
            class="btn btn-danger btn-sm" onclick="return confirm ('Apakah anda akan menghapus data ini?')">Hapus</a>
    </td>
</tr>
<?php $nomor++; endforeach; ?>
    
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>