<?php
$koneksi_user = mysqli_connect("localhost", "root", "", "blog_user");
?>