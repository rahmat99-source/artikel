<?php
include 'koneksi.php';

$id = $_GET['id'];
$sql = mysqli_query($koneksi, "SELECT * FROM artikel WHERE id='$id'");
$artikel = mysqli_fetch_array($sql);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Artikel</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
        margin: 60px 10px;
        min-height: 2000px;
    }
    h1 {
        text-align: center;
    }
    .container {
      display: flex;
      float: left;
      padding: 20px 0;
      height: 100%;;
      width: 100%;
      
    }
</style>
</head>
<body>
    <h1>Edit Artikel</h1>
<br><br>
<form action="update_artikel.php" enctype="multipart/form-data" method="POST">

    <!-- <input type="hidden" name="id_artikel" value=""> -->
    <input type="hidden" name="id_user" value="<?php echo $artikel['user_id']?>">
 
    <!-- <label for="formGroupExampleInput" class="form-label">ID Artikel</label> -->
    <input name="id" type="hidden" value="<?php echo $artikel['id']?>" class="form-control" id="formGroupExampleInput" placeholder="Masukan ID">

<div class="mb-3">
  <label for="judul" class="form-label"><b>Judul</b></label>
  <input type="text" name="judul" class="form-control" id="judul"
  value="<?php echo $artikel['judul'] ?>"
  placeholder="masukan judul">
</div>

<label for="kategori" class="form-label"><b>Kategori</b></label>
<select name="kategori_id" class="form-select" aria-label="Default select example"
  value="<?php echo $artikel['kategori_id'] ?>">
<?php
  $kategori = mysqli_query($koneksi, "SELECT * FROM kategori");
  while ($k = mysqli_fetch_assoc($kategori)) {
    echo '<option value="'.$k['id'].'">'.$k['nama_kategori'].'</option>';
  }
?>
</select>

<div class="mb-3">
  <label for="tanggal_Publish" class="form-label"><b>Tanggal Publish</b></label>
  <input type="date" name="tanggal_publish" class="form-control" id="tanggal_Publish" placeholder="" value="<?php echo $artikel['tanggal_publish'] ?>">
</div>

<div class="mb-3">
  <label for="isiArtikel" class="form-label"><b>Isi Artikel</b></label>
  <textarea class="form-control" name="isi_artikel" id="isiArtikel" rows="10" placeholder="isi artikel.." ><?php echo $artikel['isi_artikel'] ?></textarea>
</div>

<div class="input-group mb-3">
  <input type="file" name="cover" class="form-control" id="formFileMultiple" 
  value="<?php echo $artikel['cover'] ?>" multiple>
  <label class="input-group-text" for="cover"><b>Cover</b></label>
</div>

<label for="statusaktif" class="form-label"><b>Status Aktiv</b></label>
<select name="status_aktif" class="form-select" value="<?php echo $artikel['status_aktif'] ?>" aria-label="Default select example">
  <option selected>Status Aktiv</option>
  <option value="1">Aktiv</option>
  <option value="0">Non Aktiv</option>
</select>

<div class="container">
    <button type="submit"  class="btn btn-primary">Simpan Artikel</button>
    <a href="artikel.php" class="btn btn-secondary">Kembali</a>
</div>
</form>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
