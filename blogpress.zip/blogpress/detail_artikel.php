<?php
include 'koneksi.php';

$articleId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch article details
$articleQuery = "SELECT * FROM artikel WHERE id = $articleId";
$articleResult = mysqli_query($koneksi, $articleQuery);
$article = mysqli_fetch_assoc($articleResult);

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($koneksi, $_POST['name']);
    $comment = mysqli_real_escape_string($koneksi, $_POST['comment']);

    if (!empty($name) && !empty($comment)) {
        $insertCommentQuery = "INSERT INTO comments (article_id, name, comment) VALUES ($articleId, '$name', '$comment')";
        mysqli_query($koneksi, $insertCommentQuery);
    }
}

// Fetch comments for the article
$commentsQuery = "SELECT * FROM comments WHERE article_id = $articleId ORDER BY created_at DESC";
$commentsResult = mysqli_query($koneksi, $commentsQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['judul']); ?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <!-- Back Button -->
    <a href="index.php" class="btn btn-secondary mb-3">Kembali ke Beranda</a>

    <h2><?php echo htmlspecialchars($article['judul']); ?></h2>
    <img src="file_cover/<?php echo htmlspecialchars($article['cover']); ?>" alt="Cover Image" class="img-fluid mb-4">
    <p><?php echo nl2br(htmlspecialchars($article['isi_artikel'])); ?></p>

    <h3>Komentar</h3>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="comment" class="form-label">Komentar</label>
            <textarea name="comment" id="comment" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Komentar</button>
    </form>

    <h4 class="mt-4">Daftar Komentar</h4>
    <ul class="list-group">
        <?php while ($comment = mysqli_fetch_assoc($commentsResult)) : ?>
            <li class="list-group-item">
                <strong><?php echo htmlspecialchars($comment['name']); ?></strong> <br>
                <small><?php echo date('d-m-Y H:i', strtotime($comment['created_at'])); ?></small>
                <p><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
