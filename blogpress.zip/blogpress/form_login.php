<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    p{
        justify-content: center;
    }
    .background{
      background-color: skyblue;
    }
    .container {
      display: flex;
      justify-content: center; /* Mengatur posisi horizontal */
      align-items: center;    /* Mengatur posisi vertikal */
      height: 50px;         /* Menggunakan tinggi viewport */
    }
    .registrasi{
      display: flex;
      justify-content: center;
    }   
</style>


</head>
<body class="background">

<main class="form-signin w-25 m-auto shadow rounded-4 p-4 bg-white mt-5">
  <form action="login.php" method="POST">
    <h1 class="h3 mb-3 fw-normal text-center" >Silahkan Login</h1>
<br>
    <div class="form-floating mb-2">
      <input name="nama_user" type="text" class="form-control" id="floatingInput" placeholder="name@example.com">
      <label for="floatingInput">User Name</label>
    </div>
    
    <div class="form-floating">
      <input name="password" type="password" class="form-control" id="floatingPassword" placeholder="Password">
      <label for="floatingPassword">Password</label>
    </div>

    <div class="form-check text-start my-3">
      <input class="form-check-input" type="checkbox" value="remember-me" id="flexCheckDefault">
      <label class="form-check-label" for="flexCheckDefault">
        Remember me
      </label>
    </div>

    <div class="container pt-5 ">
      <button class="btn btn-primary w-75 py-2" type="submit" name="login">Sign in</button>
    </div>    
    <div class="container pt-5 pb-5 ">
      <button class="btn btn-secondary w-75 py-2" type="submit">register</button>
    </div>    
    
  </form>
</main>


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>