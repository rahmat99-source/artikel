<?php
include 'koneksi.php';
include 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    h1{
        text-align: center;
        padding-top: 100px;
    }
    .tambah {
        padding-left:  10px;
        padding-bottom: 20px;
    }
    body {
        min-height: 2000px;
    }
</style>
</head>

<body>
    <h1>Kategori</h1>
<br><br>

<div class="tambah">
    <a href="tambah_kategori.php" class="btn btn-primary ">Tambah Kategori</a>
</div>

<div class="m-auto">
    <table class="table table-hover table-primary w-100 m-auto text-center">
        <tr>
            <th>Nomor</th>
            <th>Kategori</th>
            <th>Aksi</th>
        </tr>

<?php
$nomor = 1;
$kategori = mysqli_query($koneksi, "SELECT * FROM kategori");
while($row = mysqli_fetch_array($kategori)) { 
?>

<tr>
    <td><?php echo $nomor ?></td>
    <td><?php echo $row['nama_kategori']?></td>
    <td>
        <a href="edit_kategori.php?id=<?php echo $row['id']?>"
        class="btn btn-primary">Edit</a>

        <a href="hapus_kategori.php?id=<?php echo $row['id']?>"
        onclick="return confirm('Yakin ingin menghapus data ini?')" 
        class="btn btn-danger">Hapus</a>
    </td>
</tr>
<?php $nomor++; } ?>
</table>
</div>


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>