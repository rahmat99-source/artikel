<?php
include 'koneksi.php';

// Ambil kata kunci pencarian dari URL jika ada
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Mengatur jumlah artikel per halaman
$articlesPerPage = 10;

// Mengambil halaman saat ini dari URL, default ke 1
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$currentPage = max($currentPage, 1); // Pastikan halaman minimal 1

// Hitung offset untuk query
$offset = ($currentPage - 1) * $articlesPerPage;

// Query untuk menghitung total artikel
$countQuery = "SELECT COUNT(*) as total FROM artikel";
if ($searchTerm) {
    $countQuery .= " WHERE judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$countResult = mysqli_query($koneksi, $countQuery);
$totalArticles = mysqli_fetch_assoc($countResult)['total'];

// Hitung total halaman
$totalPages = ceil($totalArticles / $articlesPerPage);

// Query untuk mengambil artikel berdasarkan kata kunci pencarian dan pagination, serta kategori
$query = "SELECT artikel.*, kategori.nama_kategori 
          FROM artikel 
          LEFT JOIN kategori ON artikel.kategori_id = kategori.id";
if ($searchTerm) {
    $query .= " WHERE judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$query .= " LIMIT $offset, $articlesPerPage";

$rows = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Artikel Users</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
            font-family: sans-serif;
        }
        body {
            background-color: #343a40; /* Warna latar belakang gelap */
        }
        .about, .contact {
            padding: 20px;
            color: white;
        }
        .card {
            transition: transform 0.6s;
            box-sizing: border-box;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .go {
            height: 40px;
            width: 50px;
            border-radius: 5px;
            background-color: white;
            transition: 1s;
        }
        .go:hover {
            rotate: 360deg;
            border-radius: 50px;
            background-color: lightgreen;
        }
        span {
            color: red;
        }
        
        /* New styles for the article title hover effect */
        .card-title a {
            color: #333; /* Default color */
            text-decoration: none; /* No underline by default */
        }

        .card-title a:hover {
            color: red; /* Change color on hover */
            text-decoration: underline; /* Underline on hover */
        }
        
    </style>
</head>
<body>

<!-- NAVBAR START -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary position-fixed z-3 w-100">
    <div class="container-fluid">
        <a class="navbar-brand ps-5 fw-bold fs-4" href="#">BLOGpress.com</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end text-bg-dark" id="offcanvasNavbar2">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">Offcanvas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body pe-5">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 align-items-center">
                    <li class="nav-item"><a class="nav-link" href="home_user.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Kategori</a>
                        <ul class="dropdown-menu">
                            <?php
                            // Fetch categories from the database
                            $kategori_query = "SELECT kategori.id, kategori.nama_kategori, COUNT(artikel.id) as jumlah_artikel
                                               FROM kategori LEFT JOIN artikel ON kategori.id = artikel.kategori_id
                                               GROUP BY kategori.id";
                            $kategori_result = $koneksi->query($kategori_query);

                            if ($kategori_result->num_rows > 0) {
                                // Output data for each category
                                while ($kategori = $kategori_result->fetch_assoc()) { ?>
                                    <li>
                                        <a href="kategori_detail_user.php?id=<?php echo $kategori['id'];?>">
                                            <?php echo $kategori['nama_kategori']; ?>
                                             (<?php echo $kategori['jumlah_artikel'];?>)
                                        </a>
                                    </li>
                                    <?php }
                                } else {
                                    echo "<li>No categories found.</li>";
                                } ?>
                        </ul>
                    </li>
                </ul>

                <!-- Searching -->
                <div class="d-flex align-items-center">
                <form class="d-flex mt-3 mt-lg-2 me-lg-5" method="GET" action="">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search.." value="<?php echo htmlspecialchars($searchTerm); ?>">
                    <button class="go" type="submit">Go</button>
                </form>
                </div>
                <!-- End searching -->

                <div class="d-flex align-items-center mx-md-3">
                    <a href="tambah_artikel_user.php" class="btn btn-outline-light">Get started</a>
                </div>

                <div class="d-flex align-items-center">
                    <a href="logout.php" class="btn btn-outline-danger" onclick="return confirm ('Apakah anda ingin keluar?')">Logout</a>
                </div>

            </div>
        </div>
    </div>
</nav>
<!-- NAVBAR END -->

<!-- Hero Section Start -->
<section style="min-height: 100vh; 
                          display: flex; 
                          align-items: center; 
                          background-image: url('img/hero.jpeg'); 
                          background-size: cover;">
    <main style="margin-left: 50px; margin-bottom: -300px;">
        <h1 style="font-weight: bolder; font-size: 62px; color: white;">Chosen by Millions,<br>Perfect for You</h1>
        <p style="font-size: 24px; color: white;">Everything you need to build and grow any website—all in one place.</p>
        <br>
        <a href="selengkapnya.php" class="btn btn-primary">Selengkapnya</a>
    </main>
</section>
<!-- Hero Section End -->

<!-- About Section -->
<div class="about" id="about">
<ul>
    <h2>About</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo nesciunt, repellat voluptate officia hic obcaecati praesentium natus perferendis recusandae minima dolores autem nostrum minus exercitationem quod! Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium in rerum nam quis dolorem sunt consectetur, illo quia. Deleniti quia vel necessitatibus ipsam tempore laborum illum, aperiam aspernatur doloremque similique. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda, debitis dolorem? Quod animi id illo delectus? Earum, molestiae qui aspernatur eos similique, quam non quisquam possimus perferendis sunt ipsa maxime excepturi ipsum vitae eaque facere. Enim, impedit atque. Odio voluptas ducimus dicta saepe nostrum corrupti id, officia laborum totam molestias delectus quam fugiat, cum est porro possimus. Hic excepturi incidunt dolores veritatis, sapiente fugiat blanditiis impedit voluptas veniam ea totam porro nesciunt animi saepe, quos fuga? Neque culpa nihil eligendi rem esse animi dolor, molestias quas inventore. Rem quaerat, cum vel similique repellendus possimus id, dolorem, aperiam omnis cupiditate molestiae!</p>
</ul>
</div>

<!-- Contact Section -->
<div class="contact" id="contact">
<ul>
    <h2>Contact</h2>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo nesciunt, repellat voluptate officia hic obcaecati praesentium natus perferendis recusandae minima dolores autem nostrum minus exercitationem quod! Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet distinctio aspernatur beatae dolorem natus quisquam nisi. Natus officiis debitis quia ipsa dignissimos, rerum perspiciatis ipsam earum expedita unde, possimus accusantium. Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum veritatis, qui cum asperiores architecto cumque sed dolorum nesciunt illum, aut odit. Corporis rem at quos expedita esse quo fugit beatae dolore doloribus, natus porro similique quia sequi ipsam voluptas, numquam perferendis magnam. Accusamus recusandae, ea cupiditate accusantium reprehenderit nihil quas temporibus. Quaerat nobis eos, voluptas placeat doloremque molestiae reiciendis consectetur nihil animi odio illum sed voluptate, blanditiis, deserunt commodi soluta consequuntur recusandae? Sint laudantium voluptates doloremque et molestias nobis ea quibusdam provident porro modi architecto dolorum fugit eius non, ex pariatur molestiae aut nam! Excepturi perspiciatis quis sint totam. Facilis!</p>
</ul>    
</div>

<!-- Artikel Section -->
<div style="color: #fff; text-align: center;">
    <h2>Baca Artikel Populer</h2>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">
        <?php while ($row = mysqli_fetch_assoc($rows)) : ?>
            <div class="col-md-4 mb-4 w-50 h-25" style="box-sizing: border-box;">
                <div class="card bg-light text-dark" >
                    <a href="detail_artikel.php?id=<?php echo $row['id'] ?>">
                    <img src="file_cover/<?php echo $row['cover'] ?>" class="card-img-top" alt="Cover Image">
                    <div class="card-body">
                        <h5 style="font-style: italic;" class="card-title">
                            <a id="title" href="detail_artikel.php?id=<?php echo $row['id'] ?>">
                                <?php echo $row['judul'] ?>
                            </a>
                        </h5>
                        <p><small><span><?= htmlspecialchars($row['nama_kategori']); ?></span> | <?= $row['tanggal_publish']; ?></small></p>
                        <p class="card-text"><?php echo substr($row['isi_artikel'], 0, 100) . '...'; ?></p>
                    </div>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>



<!-- Pagination -->
<div>
<nav aria-label="Pagination">
    <ul class="pagination justify-content-center my-4">
        <?php if ($currentPage > 1): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage - 1; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Previous</a></li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php echo $i == $currentPage ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($currentPage < $totalPages): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage + 1; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Next</a></li>
        <?php endif; ?>
    </ul>
</nav>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
