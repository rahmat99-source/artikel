<?php
include 'koneksi.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Tambah User</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
        margin: 60px 10px;
    }
    h1 {
        text-align: center;
    }
    .btn {
        margin: 0px ;
        
    }
</style>
</head>
<body>
    <h1>Form Tambah User</h1>
<br><br>
<form action="simpan_user.php" method="POST">

<!-- <input type="hidden" name="id"> -->

<div class="mb-3">
  <label for="namaUser" class="form-label">Nama User</label>
  <input type="text" name="nama_user" class="form-control" id="namaUser" 
  placeholder="masukan nama pengguna anda">
</div>

<div class="mb-3">
  <label for="email" class="form-label">Email address</label>
  <input type="email" name="email" class="form-control" id="email" 
  placeholder="nama@gmail.com">
</div>

<label for="password" class="form-label">Password</label>
<input type="password" name="password" id="password" class="form-control" aria-describedby="passwordHelpBlock" placeholder="masukan kata sandi">

<div id="passwordHelpBlock" class="form-text">
  Your password must be 8-20 characters long, contain letters and numbers, and must not contain spaces, special characters, or emoji.
</div>

<select name="is_admin" class="form-select" aria-label="Default select example">
  <option selected>IS Admin</option>
  <option value="0">user</option>
  <option value="1">admin</option>
</select>

<div class="btn">
    <button type="submit" name="submit" class="btn btn-primary">Simpan User</button>
    <a href="users.php" class="btn btn-secondary">Kembali</a>
</div>
</form>


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>