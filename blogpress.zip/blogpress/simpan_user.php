<?php
include 'koneksi.php';

$id_kategori = $_POST['id'];
$nama_user = $_POST['nama_user'];
$email = $_POST['email'];
$password = $_POST['password'];
$is_admin = $_POST['is_admin'];

$simpan = mysqli_query($koneksi, "INSERT INTO `users`( `nama_user`, `email`, `password`, `is_admin`) VALUES ( '$nama_user','$email','$password','$is_admin')");

header('location: users.php');
?>