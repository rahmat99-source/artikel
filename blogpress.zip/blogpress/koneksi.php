<?php
// $host = "localhost";
// $admin = "root";
// $pass = "";
// $database = "blogpress";
// $koneksi = mysqli_connect($host,$admin,$pass,$database);
?>
<?php
$koneksi = mysqli_connect("localhost", "root", "", "blogpress");
?>