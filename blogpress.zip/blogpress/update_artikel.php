<?php
include 'koneksi.php';

$idartikel = $_POST["id"];
$iduser = $_POST["id_user"];
$judul = $_POST["judul"];
$namakategori = $_POST["kategori_id"];
$tanggalpublish = $_POST["tanggal_publish"];
$isiartikel = $_POST["isi_artikel"];
$statusaktif = $_POST["status_aktif"];

$target_dir = "file_cover/";
$nameFile = $_FILES["cover"]["name"];
$target_file = $target_dir . basename($nameFile);
$namasementara = $_FILES['cover']['tmp_name'];
$terupload = move_uploaded_file($namasementara, $target_file);

$update = "UPDATE artikel SET id='$idartikel', user_id='$iduser',judul='$judul',kategori_id='$namakategori',tanggal_publish='$tanggalpublish',isi_artikel='$isiartikel',status_aktif='$statusaktif',cover='$nameFile' WHERE id ='$idartikel'";
        
$sql = mysqli_query($koneksi, $update);
header('location:artikel.php');
?>