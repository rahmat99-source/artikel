<?php
include 'koneksi.php';

$id = $_GET['id'];

$sql = mysqli_query($koneksi, "SELECT * FROM kategori WHERE id = '$id'");

$kategori = mysqli_fetch_array($sql);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
</head>
<body>
    <h1 align="center">Edit Kategori</h1>
<div class="main">
    <form action="update_kategori.php" method="POST">

    <div class="mb-3">
      <input value="<?php echo $kategori['id']; ?>" type="hidden" name="id" class="form-control" id="idkategori" 
      placeholder="Masukan ID kategori">
    </div>

    <div class="mb-3">
      <label for="namaKategori" class="form-label">Nama Kategori</label>
      <input value="<?php echo $kategori['nama_kategori']; ?>" type="text" name="nama_kategori" class="form-control" id="namaKategori" 
      placeholder="Masukan Nama Kategori" required>
    </div>

      <button type="submit" class="btn btn-primary ">Simpan Kategori</button>
      <a class="btn btn-secondary" href="kategori.php">Kembali</a></button>

    </form>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>