<?php
include 'koneksi.php';

// Periksa apakah 'id' ada dalam URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    die("Error: ID tidak ditemukan.");
}

// Ambil kata kunci pencarian dari URL jika ada
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Mengatur jumlah artikel per halaman
$articlesPerPage = 10;

// Mengambil halaman saat ini dari URL, default ke 1
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$currentPage = max($currentPage, 1);

// Hitung offset untuk query
$offset = ($currentPage - 1) * $articlesPerPage;

// Query untuk menghitung total artikel berdasarkan kategori
$countQuery = "SELECT COUNT(*) as total FROM artikel WHERE kategori_id='$id'";
if ($searchTerm) {
    $countQuery .= " AND judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$countResult = mysqli_query($koneksi, $countQuery);
$totalArticles = mysqli_fetch_assoc($countResult)['total'];

// Hitung total halaman
$totalPages = ceil($totalArticles / $articlesPerPage);

// Query untuk mengambil artikel berdasarkan kategori dan kata kunci pencarian
$query = "SELECT * FROM artikel WHERE kategori_id='$id'";
if ($searchTerm) {
    $query .= " AND judul LIKE '%" . mysqli_real_escape_string($koneksi, $searchTerm) . "%'";
}
$query .= " LIMIT $offset, $articlesPerPage";

$rows = mysqli_query($koneksi, $query);

// Ambil nama kategori dari database berdasarkan id
$kategoriQuery = "SELECT nama_kategori FROM kategori WHERE id='$id'";
$kategoriResult = mysqli_query($koneksi, $kategoriQuery);
$kategoriData = mysqli_fetch_assoc($kategoriResult);
$namaKategori = $kategoriData['nama_kategori'] ?? 'Kategori Tidak Ditemukan';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel Kategori</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            outline: none;
            border: none;
            text-decoration: none;
            font-family: sans-serif;
        }
        body {
            background-color: #343a40;
        }
        .about, .contact {
            padding: 20px;
            color: white;
        }
        .hero {
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            background-image: url('img/hero.jpeg'); 
            background-size: cover;
        }
        .card {
            transition: transform 0.6s;
            box-sizing: border-box;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .go {
            height: 40px;
            width: 50px;
            border-radius: 5px;
            background-color: white;
            transition: 1s;
        }
        .go:hover {
            rotate: 360deg;
            border-radius: 50px;
            background-color: lightgreen;
        }
        span {
            color: darkred;
        }
        
        .card-title a {
            color: #333;
            text-decoration: none;
        }
        .card-title a:hover {
            color: red;
            text-decoration: underline;
        }

        /* New styles for dropdown menu items */
        .dropdown-menu {
            width: 250px; /* Atur lebar dropdown sesuai kebutuhan */
            text-align: center; /* Center text in dropdown */
        }

        .dropdown-menu a {
            color: black; /* Warna teks item dropdown menjadi hitam */
            display: block; /* Pastikan link mengambil seluruh lebar */
        }

        .dropdown-menu a:hover {
            color: red; /* Warna saat hover */
            background-color: rgba(255, 255, 255, 0.2); /* Background saat hover */
        }
    </style>
</head>
<body>

<!-- NAVBAR START -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary position-fixed z-3 w-100">
    <div class="container-fluid">
        <a class="navbar-brand ps-5 fw-bold fs-4" href="#">BLOGpress.com</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end text-bg-dark" id="offcanvasNavbar2">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">Offcanvas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body pe-5">
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 align-items-center">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Kategori</a>
                        <ul class="dropdown-menu">
                        <?php
                        $kategori_query = "SELECT kategori.id, kategori.nama_kategori, COUNT(artikel.id) as jumlah_artikel
                                           FROM kategori LEFT JOIN artikel ON kategori.id=artikel.kategori_id
                                           GROUP BY kategori.id";
                        $kategori_result = $koneksi->query($kategori_query);

                        if ($kategori_result->num_rows > 0) {
                            while ($kategori = $kategori_result->fetch_assoc()) { ?>
                                <li>
                                    <a href="kategori_detail.php?id=<?php echo $kategori['id'];?>"><?php echo $kategori['nama_kategori']; ?> (<?php echo $kategori['jumlah_artikel'];?>)</a>
                                </li>
                                <?php }
                        } else {
                            echo "<li>No categories found.</li>";
                        }
                        ?>
                        </ul>
                    </li>
                </ul>

                <!-- Searching -->
                <div class="d-flex align-items-center">
                    <form class="d-flex mt-3 mt-lg-2 me-lg-5" method="GET" action="">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search.." value="<?php echo htmlspecialchars($searchTerm); ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>"> 
                        <button class="go" type="submit">Go</button>
                    </form>
                </div>
                <!-- End searching -->
                 
                <div class="d-flex align-items-center">
                    <a href="index.php" class="btn btn-outline-light">Login</a>
                </div>

            </div>
        </div>
    </div>
</nav>
<!-- NAVBAR END -->

<!-- Hero Section Start -->
<section class="hero">
    <main style="margin-left: 50px; margin-bottom: -300px;">
        <h1 style="font-weight: bolder; font-size: 62px; color: white;">Chosen by Millions,<br>Perfect for You</h1>
        <p style="font-size: 24px; color: white;">Everything you need to build and grow any website—all in one place.</p>
        <br>
        <a href="selengkapnya.php" class="btn btn-primary">Selengkapnya</a>
    </main>
</section>
<!-- Hero Section End -->

<!-- Artikel Section -->
<div style="color: #fff; text-align: center; margin: 100px auto;">
    <h2 style="text-decoration: underline;"><?php echo htmlspecialchars($namaKategori); ?></h2>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">
        <?php while ($row = mysqli_fetch_assoc($rows)) : ?>
            <div class="col-md-4 mb-4">
                <div class="card bg-light text-dark">
                    <img src="file_cover/<?php echo $row['cover'] ?>" class="card-img-top" alt="Cover Image">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $row['judul'] ?></h5>
                        <p class="card-text"><?php echo substr($row['isi_artikel'], 0, 100) . '...'; ?></p>
                        <a href="detail_artikel.php?id=<?php echo $row['id'] ?>" class="btn btn-primary">Baca Selengkapnya</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Pagination -->
<div>
<nav aria-label="Pagination">
    <ul class="pagination justify-content-center my-4">
        <?php if ($currentPage > 1): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage - 1; ?>&id=<?php echo $id; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Previous</a></li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?php echo $i == $currentPage ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>&id=<?php echo $id; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($currentPage < $totalPages): ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $currentPage + 1; ?>&id=<?php echo $id; ?>&search=<?php echo htmlspecialchars($searchTerm); ?>">Next</a></li>
        <?php endif; ?>
    </ul>
</nav>
</div>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
