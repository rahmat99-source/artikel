<?php
include 'koneksi.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
<style>
    body {
        margin: 60px 10px;
    }
    h1 {
        text-align: center;
    }
    .container {
        display: flex;
        float: left;
        padding: 20px 0;
        height: 100%;;
        width: 100%;
    }
</style>
</head>
<body>
    <h1>Form Tambah Kategori</h1>
<br><br>
<form action="simpan_kategori.php" method="POST">
<!-- 
<input type="hidden" name="id"> -->

<div class="mb-3">
  <label for="namaKategori" class="form-label">Nama Kategori</label>
  <input type="text" name="nama_kategori" class="form-control" id="namaKategori" placeholder="masukan nama kategori">
</div>

<div class="container">
    <button type="submit" class="btn btn-primary">Simpan Kategori</button>
    <a href="kategori.php" class="btn btn-secondary">Kembali</a>
</div>
</form>


<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>