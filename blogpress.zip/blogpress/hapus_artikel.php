<?php
include 'koneksi.php';

$idartikel = $_GET["id"];

$hapus = "DELETE FROM artikel WHERE id ='$idartikel' ";
        
$sql = mysqli_query($koneksi, $hapus);
header('location:artikel.php');


?>