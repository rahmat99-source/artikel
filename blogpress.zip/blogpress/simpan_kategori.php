<?php
include 'koneksi.php';

$nama_kategori = $_POST['nama_kategori'];

$simpan = mysqli_query($koneksi, "INSERT INTO `kategori`( `nama_kategori`) VALUES ('$nama_kategori') ");

header('location:kategori.php');


?>